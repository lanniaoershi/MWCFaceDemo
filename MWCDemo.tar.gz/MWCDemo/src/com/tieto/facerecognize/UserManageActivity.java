package com.tieto.facerecognize;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.InputStream;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.Gallery.LayoutParams;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.ViewSwitcher;
import com.googlecode.javacv.cpp.opencv_contrib.FaceRecognizer;
//import android.provider.MediaStore.Files;
import com.tieto.user.action.R;

public class UserManageActivity extends Activity implements
		AdapterView.OnItemSelectedListener, ViewSwitcher.ViewFactory
{

	FaceLabels thelabels;
	int count = 0;
	Bitmap bmlist[];
	String namelist[];
	String mPath = "";
	TextView name;
	Button buttonDel;
	Button buttonAdd;
	Button buttonRename;
	
	ImageButton buttonBack;
	@SuppressWarnings("deprecation")
	Gallery g;
	Recognizer fr;
	// ToggleButton toggleButtonGrabar, toggleButtonTrain, buttonSearch;
	TextView textname;
	TextView textState;
	TextView textresult, test;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.user_management);
		// toggleButtonTrain = (ToggleButton) findViewById(R.id.toggleButton1);
		textresult = (TextView) findViewById(R.id.textView2);
		textname = (TextView) findViewById(R.id.textname);
		textState = (TextView) findViewById(R.id.textViewState);
		// buttonSearch = (ToggleButton) findViewById(R.id.buttonBuscar);
		// toggleButtonGrabar = (ToggleButton)
		// findViewById(R.id.toggleButtonGrabar);

		name = (TextView) findViewById(R.id.textView1);
		buttonDel = (Button) findViewById(R.id.buttonDel);
		buttonBack = (ImageButton) findViewById(R.id.imageButton1);
		buttonAdd = (Button) findViewById(R.id.buttonAdd);
		buttonRename = (Button) findViewById(R.id.Rename);
		

		mSwitcher = (ImageSwitcher) findViewById(R.id.switcher);
		mSwitcher.setFactory(this);
		mSwitcher.setInAnimation(AnimationUtils.loadAnimation(this,
				android.R.anim.fade_in));
		mSwitcher.setOutAnimation(AnimationUtils.loadAnimation(this,
				android.R.anim.fade_out));

		// Bundle bundle = getIntent().getExtras();
		//
		// mPath = bundle.getString("path");
		mPath = Environment.getExternalStorageDirectory() + "/facesdata/";

		thelabels = new FaceLabels(mPath);
		thelabels.Read();

		count = 0;
		int max = thelabels.max();

		for (int i = 0; i <= max; i++)

		{
			if (thelabels.get(i) != "")
			{
				count++;
			}
		}

		bmlist = new Bitmap[count];
		namelist = new String[count];
		count = 0;
		for (int i = 0; i <= max; i++)
		{
			if (thelabels.get(i) != "")
			{
				File root = new File(mPath);
				final String fname = thelabels.get(i);
				FilenameFilter pngFilter = new FilenameFilter()
				{
					public boolean accept(File dir, String name)
					{
						return name.toLowerCase().startsWith(
								fname.toLowerCase() + "-");

					};
				};
				File[] imageFiles = root.listFiles(pngFilter);
				if (imageFiles.length > 0)
				{
					InputStream is;
					try
					{
						is = new FileInputStream(imageFiles[0]);

						bmlist[count] = BitmapFactory.decodeStream(is);
						namelist[count] = thelabels.get(i);

					} catch (FileNotFoundException e)
					{
						// TODO Auto-generated catch block
						Log.e("File erro", e.getMessage() + " " + e.getCause());
						e.printStackTrace();
					}

				}
				count++;
			}
		}

		g = (Gallery) findViewById(R.id.gallery1);
		g.setAdapter(new ImageAdapter(this));
		g.setOnItemSelectedListener(this);

		buttonBack.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{

				finish();

			}
		});

	

		buttonRename.setOnClickListener(new View.OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				// TODO Auto-generated method stub
				File root = new File(mPath);

				FilenameFilter pngFilterName = new FilenameFilter()
				{
					// String tmpname = name.getText().toString();

					public boolean accept(File dir, String n)
					{

						final String s = textname.getText().toString();

						Log.e("ssss", s);

						// String s1 = tmpname;
						// Log.e("ssss1", s1);

						return n.toLowerCase()
								.startsWith(s.toLowerCase() + "-");

					};
				};

				File[] imageFilesName = root.listFiles(pngFilterName);
				File f_old = null;
				File f_new = null;
				int i = 0;
				String str = name.getText().toString();
				Log.e("name", str);
				if (imageFilesName != null)
				{
					Log.e("kong", "aaaaaaaaa" + imageFilesName.length);

				}
				for (File ifileName : imageFilesName)
				{
					Log.e("iii", i + "");
					f_old = ifileName;
					Log.e("filename", f_old.getName().toString());
					f_new = new File(mPath+str + "-" + i + ".jpg");
					Log.e("newfilename", f_new.getName().toString());
					i++;

			

					// ////////////////////////////////////
					int l = 0;
					Log.e("list", namelist[l]);
					l++;
					// //////////////////////////////////

					for (int k = 0; k < count; k++)
					{
						if (namelist[k].equalsIgnoreCase(textname.getText()
								.toString()))
						{

							namelist[k] = name.getText().toString();

							refresh();
							// finish();
							// startActivity(getIntent());

							//
							break;
						}
					}
					
				if(f_old.renameTo(f_new)){
					Log.e("ren","chongminiandiada");
				}
					
					refresh();

				}

			}
		});
		buttonAdd.setOnClickListener(new View.OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				// TODO Auto-generated method stub

				Intent i = new Intent(
						com.tieto.facerecognize.UserManageActivity.this,
						com.tieto.facerecognize.FaceRecognizeActivity.class);

				// com.tieto.user.action.FaceRecognizeActivity.toggleButtonTrain.setChecked(false);

				startActivity(i);
				com.tieto.facerecognize.FaceRecognizeActivity.toggleButtonTrain
						.performClick();
				// if(null == toggleButtonTrain){
				// Log.e("tog","aaaaaaaa");
				// }

			}
		});
		buttonDel.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{

				File root = new File(mPath);

				FilenameFilter pngFilter = new FilenameFilter()
				{
					public boolean accept(File dir, String n)
					{
						String s = textname.getText().toString();
						return n.toLowerCase()
								.startsWith(s.toLowerCase() + "-");

					};
				};
				File[] imageFiles = root.listFiles(pngFilter);
				for (File image : imageFiles)
				{
					image.delete();

					int i;
					for (i = 0; i < count; i++)
					{
						if (namelist[i].equalsIgnoreCase(textname.getText()
								.toString()))
						{
							int j;
							for (j = i; j < count - 1; j++)
							{
								namelist[j] = namelist[j + 1];
								bmlist[j] = bmlist[j + 1];
							}
							count--;
							refresh();
							// finish();
							// startActivity(getIntent());

							//
							break;
						}
					}
				}
			}
		});
	}

	public void refresh()
	{
		g.setAdapter(new ImageAdapter(this));
	}

	public void onItemSelected(AdapterView<?> parent, View v, int position,
			long id)
	{
		// mSwitcher.setImageURI(bmlist[0]);
		mSwitcher.setImageDrawable(new BitmapDrawable(getResources(),
				bmlist[position]));
		textname.setText(namelist[position]);
	}

	public void onNothingSelected(AdapterView<?> parent)
	{
	}

	public View makeView()
	{
		ImageView i = new ImageView(this);
		i.setBackgroundColor(0xFF000000);
		i.setScaleType(ImageView.ScaleType.FIT_CENTER);
		i.setLayoutParams(new ImageSwitcher.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		return i;
	}

	private ImageSwitcher mSwitcher;

	public class ImageAdapter extends BaseAdapter
	{
		public ImageAdapter(Context c)
		{
			mContext = c;
		}

		public int getCount()
		{

			return count;
		}

		public Object getItem(int position)
		{
			return bmlist[position];
		}

		public long getItemId(int position)
		{
			return position;
		}

		@SuppressWarnings("deprecation")
		public View getView(int position, View convertView, ViewGroup parent)
		{
			ImageView i = new ImageView(mContext);
			i.setImageBitmap(bmlist[position]);

			// i.setImageResource(mThumbIds[position]);
			// i.setScaleType(ImageView.ScaleType.FIT_CENTER);
			// i.setAdjustViewBounds(true);

			i.setLayoutParams(new Gallery.LayoutParams(240, 240));
			// i.setBackgroundResource(R.drawable.picture_frame);
			return i;
		}

		private Context mContext;

	}

}